import React, { useState } from 'react';
import { Icons } from './Icons';
import { StatusBadge } from './StatusBadge';

// Pitch Visualizer Component (Internal Helper)
function PitchVisualizer({ pitch }) {
    const rise = parseInt(pitch?.split('/')[0]) || 6;
    const angle = Math.atan(rise / 12) * (180 / Math.PI);

    return (
        <div className="pitch-visualizer">
            <div className="roof-icon">
                <svg viewBox="0 0 100 60" fill="none">
                    <defs>
                        <linearGradient id="roofGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#667eea" />
                            <stop offset="100%" stopColor="#764ba2" />
                        </linearGradient>
                    </defs>
                    <polygon
                        points={`50,${10 - rise} 95,35 95,55 5,55 5,35`}
                        fill="url(#roofGrad)"
                        stroke="#4c1d95"
                        strokeWidth="2"
                    />
                    <polygon
                        points={`50,${10 - rise} 5,35 95,35`}
                        fill="#8b5cf6"
                        stroke="#4c1d95"
                        strokeWidth="2"
                    />
                    <rect x="40" y="40" width="20" height="15" fill="#1e1b4b" rx="2" />
                </svg>
            </div>
            <div style={{ marginLeft: 'var(--space-4)', textAlign: 'left' }}>
                <div style={{ fontSize: 'var(--font-size-2xl)', fontWeight: '700', color: 'var(--color-gray-900)' }}>
                    {pitch || 'Unknown'}
                </div>
                <div style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-gray-500)' }}>
                    Roof Pitch ({Math.round(angle)}°)
                </div>
            </div>
        </div>
    );
}

// NOTE: UpgradeModal removed in favor of Tier2Setup page

export default function ResultCard({ data, onUpgrade, isUpgrading, tier2Disabled }) {
    const isVerified = data.status === 'VERIFIED';
    const isPending = data.status === 'PENDING';
    const showUpgrade = data.status === 'ESTIMATE' && !isPending;
    const hasValidData = data.total_area_sqft > 0;

    const handleUpgradeClick = () => {
        // Trigger navigation to full setup page
        // App.jsx will handle switching view to 'tier2_setup'
        // onUpgrade here expects to be called to INIT the flow
        if (onUpgrade) onUpgrade();
    };

    return (
        <div className={`result-card ${isVerified ? 'tier-2' : ''}`}>
            <div className="result-card-grid">

                {/* === LEFT COLUMN: Visuals & Core Metrics === */}
                <div className="result-left-col">
                    {/* Header (Title + Address) */}
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 'var(--space-2)' }}>
                            <StatusBadge status={data.status} />
                            <div style={{ textAlign: 'right' }}>
                                <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-gray-400)' }}>
                                    {data.source === 'EAGLEVIEW' ? 'Source: EagleView' : 'Source: Google Solar'}
                                </div>
                                {data.is_cached && (
                                    <div style={{ fontSize: '10px', color: '#059669', fontWeight: 'bold', marginTop: '2px' }}>
                                        ⚡ FROM CACHE
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="result-address">{data.address}</div>
                    </div>

                    {hasValidData && (
                        <>
                            {/* Pitch Visual */}
                            <div style={{ padding: 'var(--space-4)', background: 'var(--color-gray-50)', borderRadius: 'var(--radius-lg)' }}>
                                <PitchVisualizer pitch={data.predominant_pitch} />
                            </div>

                            {/* Core Metrics Grid */}
                            <div className="primary-metrics">
                                <div className="metric highlight">
                                    <div className="metric-value">
                                        {data.total_area_sqft?.toLocaleString() || '—'}
                                    </div>
                                    <div className="metric-label">Square Feet</div>
                                </div>
                                <div className="metric">
                                    <div className="metric-value">{data.predominant_pitch || '—'}</div>
                                    <div className="metric-label">Pitch</div>
                                </div>
                                {data.squares_needed && (
                                    <div className="metric">
                                        <div className="metric-value">{data.squares_needed}</div>
                                        <div className="metric-label">Squares</div>
                                    </div>
                                )}
                            </div>

                            {/* Confidence & Quality */}
                            <div className="confidence-minimal">
                                <div className="confidence-dot" style={{
                                    background: data.confidence_score > 0.7 ? 'var(--color-success)' : 'var(--color-warning)'
                                }} />
                                <div style={{ flex: 1 }}>
                                    <strong>{Math.round((data.confidence_score || 0) * 100)}% Confidence</strong>
                                    {data.imagery_quality && (
                                        <span style={{ marginLeft: 'var(--space-2)', opacity: 0.7 }}>
                                            • {data.imagery_quality} Quality
                                        </span>
                                    )}
                                </div>
                            </div>
                        </>
                    )}

                    {/* Error Message */}
                    {data.message && (
                        <div className="error-message" style={{ marginTop: '1rem' }}>
                            <Icons.AlertTriangle />
                            <span>{data.message}</span>
                        </div>
                    )}
                </div>

                {/* === RIGHT COLUMN: Detailed Data === */}
                <div className="result-right-col">

                    {hasValidData && (
                        <>
                            {/* Extended Insights Row (Restored Full) */}
                            <div>
                                <h5 style={{
                                    fontSize: 'var(--font-size-xs)',
                                    color: 'var(--color-gray-500)',
                                    textTransform: 'uppercase',
                                    letterSpacing: '0.05em',
                                    marginBottom: 'var(--space-3)'
                                }}>
                                    Environmental & Solar Analysis
                                </h5>
                                <div className="extended-insights">
                                    {data.max_sunshine_hours_per_year && (
                                        <div className="insight-card">
                                            <div style={{ fontSize: 'var(--font-size-lg)', fontWeight: '700', color: '#f59e0b' }}>
                                                {Math.round(data.max_sunshine_hours_per_year).toLocaleString()}
                                            </div>
                                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-gray-500)' }}>Sun Hours/Year</div>
                                        </div>
                                    )}
                                    {data.carbon_offset_factor && (
                                        <div className="insight-card">
                                            <div style={{ fontSize: 'var(--font-size-lg)', fontWeight: '700', color: '#10b981' }}>
                                                {Math.round(data.carbon_offset_factor)}
                                            </div>
                                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-gray-500)' }}>kg CO₂/MWh</div>
                                        </div>
                                    )}
                                    {data.max_panels && (
                                        <div className="insight-card">
                                            <div style={{ fontSize: 'var(--font-size-lg)', fontWeight: '700', color: '#3b82f6' }}>
                                                {data.max_panels}
                                            </div>
                                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-gray-500)' }}>Max Panels</div>
                                        </div>
                                    )}
                                    {data.roof_facet_count && (
                                        <div className="insight-card">
                                            <div style={{ fontSize: 'var(--font-size-lg)', fontWeight: '700', color: 'var(--color-gray-700)' }}>
                                                {data.roof_facet_count}
                                            </div>
                                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-gray-500)' }}>Facets</div>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Roof Segments Table (Restored) */}
                            {data.roof_segments && data.roof_segments.length > 0 && (
                                <div>
                                    <h5 style={{
                                        fontSize: 'var(--font-size-xs)',
                                        color: 'var(--color-gray-500)',
                                        textTransform: 'uppercase',
                                        letterSpacing: '0.05em',
                                        marginBottom: 'var(--space-3)',
                                        display: 'flex',
                                        justifyContent: 'space-between'
                                    }}>
                                        <span>Roof Facet Details</span>
                                        <span>{data.roof_segments.length} Segments</span>
                                    </h5>
                                    <div className="segments-table-container">
                                        <table className="segments-table">
                                            <thead>
                                                <tr>
                                                    <th style={{ width: '30px' }}>#</th>
                                                    <th>Area (sqft)</th>
                                                    <th>Pitch</th>
                                                    <th>Direction</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {data.roof_segments.slice(0, 5).map((seg, idx) => (
                                                    <tr key={idx}>
                                                        <td style={{ color: 'var(--color-gray-400)' }}>{idx + 1}</td>
                                                        <td style={{ fontWeight: '600' }}>{seg.area_sqft.toLocaleString()}</td>
                                                        <td>{seg.pitch}</td>
                                                        <td>
                                                            <span style={{
                                                                fontSize: '11px',
                                                                fontWeight: '700',
                                                                color: 'var(--color-gray-600)',
                                                                background: 'var(--color-gray-100)',
                                                                padding: '2px 6px',
                                                                borderRadius: '4px'
                                                            }}>
                                                                {seg.azimuth_direction}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                        {data.roof_segments.length > 5 && (
                                            <div style={{ padding: '8px', textAlign: 'center', fontSize: '11px', color: 'var(--color-gray-500)', borderTop: '1px solid var(--color-gray-100)' }}>
                                                And {data.roof_segments.length - 5} smaller facets...
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </>
                    )}

                    {/* Upgrade / Status Section (Right Column Bottom) */}
                    <div>
                        {showUpgrade && hasValidData && (
                            <div className="upgrade-section" style={{ marginTop: '0', background: 'var(--color-primary-50)', border: '1px solid var(--color-primary-200)' }}>
                                <div className="upgrade-info" style={{ marginBottom: 'var(--space-3)' }}>
                                    <h4 style={{ fontSize: 'var(--font-size-md)', color: 'var(--color-primary-900)' }}>Verified Report Available</h4>
                                    <p style={{ fontSize: 'var(--font-size-xs)' }}>
                                        Get detailed measurements with 99% accuracy for insurance claims.
                                    </p>
                                </div>
                                <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center' }}>
                                    <button
                                        className="upgrade-button"
                                        onClick={handleUpgradeClick}
                                        disabled={isUpgrading || tier2Disabled}
                                        style={{ flex: 1, justifyContent: 'center' }}
                                    >
                                        {isUpgrading ? 'Processing...' : 'Upgrade to Tier 2'}
                                    </button>
                                    {!tier2Disabled && <span style={{ fontSize: '11px', color: 'var(--color-gray-500)' }}>~$30</span>}
                                </div>
                                {tier2Disabled && (
                                    <div style={{ fontSize: '11px', color: 'var(--color-warning)', marginTop: '4px' }}>
                                        EagleView Disabled
                                    </div>
                                )}
                            </div>
                        )}

                        {isPending && (
                            <div className="upgrade-section" style={{ marginTop: '0', background: 'var(--color-warning-light)', borderColor: 'var(--color-warning)' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                                    <div className="loading-spinner" style={{ width: 20, height: 20 }} />
                                    <div>
                                        <div style={{ fontWeight: '600', fontSize: 'var(--font-size-sm)' }}>Processing Verified Report</div>
                                        <div style={{ fontSize: 'var(--font-size-xs)' }}>This may take 2-5 minutes...</div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                </div>
            </div>
        </div>
    );
}
